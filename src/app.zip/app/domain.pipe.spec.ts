/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { DomainPipe } from './domain.pipe';

describe('DomainPipe', () => {
  it('create an instance', () => {
    const pipe = new DomainPipe();
    expect(pipe).toBeTruthy();
  });
});
